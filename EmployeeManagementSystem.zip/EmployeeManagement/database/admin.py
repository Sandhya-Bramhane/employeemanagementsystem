from django.contrib import admin
from database.models import empregister
# Register your models here.
admin.site.register(empregister)