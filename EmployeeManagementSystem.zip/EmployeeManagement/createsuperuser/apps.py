from django.apps import AppConfig


class CreatesuperuserConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'createsuperuser'
